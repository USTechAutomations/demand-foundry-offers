"""Replay synthetic source snapshots against a fresh isolated PostgreSQL.
0 matches, 1 mismatch, 2 unavailable/malformed evidence. No source execution here.
"""
import json, subprocess, uuid, time, re
from decimal import Decimal
from pathlib import Path

P = Path(__file__).resolve().parent
PREFIX = 'usta-migration-replay-'
OWN_NAME = re.compile(r'^usta-migration-replay-[0-9a-f]{32}$')
READY_ATTEMPTS = 40
READY_SLEEP = 0.25
CMD_TIMEOUT = 45
READY_TIMEOUT = 5
PRECISION_QUERIES = (
    'SELECT * FROM customer_report(80,NULL)',
    'SELECT * FROM ranked_orders(80)',
)
SCOPE = (
    'SYNTHETIC: saved SQL Server rows vs fresh PostgreSQL; '
    'not a customer migration or native metadata proof'
)


def unique_name():
    return PREFIX + uuid.uuid4().hex


def is_own_container(name):
    return isinstance(name, str) and bool(OWN_NAME.fullmatch(name))


def run(args, stdin=None, timeout=CMD_TIMEOUT):
    try:
        r = subprocess.run(args, input=stdin, text=True, capture_output=True, timeout=timeout)
    except FileNotFoundError as e:
        raise RuntimeError('command unavailable/failed: ' + args[0] + ' missing') from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeError('command unavailable/failed: ' + args[0] + ' timeout') from e
    if r.returncode:
        err = (r.stderr or '')[:300]
        raise RuntimeError('command unavailable/failed: ' + args[0] + ' ' + err)
    return (r.stdout or '').strip()


def sql(container, q):
    return run(
        ['docker', 'exec', '-i', container, 'psql', '-U', 'postgres', '-X', '-qAt', '-v', 'ON_ERROR_STOP=1'],
        q,
    )


def read(f):
    return json.loads((P / f).read_text(), parse_float=Decimal)


def compare(table, query, label, sql_fn):
    if not isinstance(table, list) or not table or not all(isinstance(x, str) for x in table[0]):
        raise ValueError('malformed source table')
    headers = table[0]
    if len(set(headers)) != len(headers) or any(len(row) != len(headers) for row in table[1:]):
        raise ValueError('malformed source rows')
    expected = [{k: Decimal(v) for k, v in zip(headers, row)} for row in table[1:]]
    actual = json.loads(
        sql_fn("SELECT coalesce(json_agg(t),'[]'::json) FROM (" + query + ") t"),
        parse_float=Decimal,
    )
    if type(actual) is not list:
        raise ValueError('malformed target rows')
    for row in actual:
        if type(row) is not dict or any(type(k) is not str or not k for k in row):
            raise ValueError('malformed target columns')
        if any(type(v) not in (int, Decimal) or (type(v) is Decimal and not v.is_finite()) for v in row.values()):
            raise ValueError('malformed target numeric value')
    return {'case': label, 'status': 'PASS' if expected == actual else 'FAIL', 'rows': len(expected)}


def docker_run_args(name):
    return [
        'docker', 'run', '--pull', 'never', '-d', '--name', name, '--network', 'none',
        '--memory', '384m', '--cpus', '1', '--pids-limit', '100',
        '--tmpfs', '/var/lib/postgresql/data:rw,size=160m',
        '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', 'postgres:15.7-alpine',
    ]


def cleanup_own(name):
    if not is_own_container(name):
        raise RuntimeError('cleanup refused: not unique own container')
    run(['docker', 'rm', '-f', name])


def wait_ready(name):
    for _ in range(READY_ATTEMPTS):
        try:
            r = subprocess.run(
                ['docker', 'exec', name, 'pg_isready', '-h', '127.0.0.1', '-U', 'postgres'],
                capture_output=True,
                timeout=READY_TIMEOUT,
            )
        except FileNotFoundError as e:
            raise RuntimeError('command unavailable/failed: docker missing') from e
        except subprocess.TimeoutExpired as e:
            raise RuntimeError('command unavailable/failed: docker timeout') from e
        if r.returncode == 0:
            return
        time.sleep(READY_SLEEP)
    raise RuntimeError('PostgreSQL startup unavailable')


def load_evidence():
    tables = read('source-tables.json')
    cases = read('cases.json')
    precision = read('source-precision-tables.json')
    from snapshot_check import validate
    if validate(tables, cases, precision)['status'] != 'PASS':
        raise ValueError('source evidence coverage missing')
    return tables[1:], cases, precision


def replay(sql_fn):
    tables, cases, precision = load_evidence()
    sql_fn((P / 'setup.sql').read_text() + (P / 'target.sql').read_text())
    results = [compare(t, c[2], c[0], sql_fn) for t, c in zip(tables, cases)]
    sql_fn(
        "INSERT INTO orders VALUES "
        "(80,80,999999999999999999.99,'2024-02-10','paid'),"
        "(81,80,999999999999999999.99,'2024-02-11','paid')"
    )
    results.extend(
        compare(t, q, 'wide-decimal-' + str(i), sql_fn)
        for i, (t, q) in enumerate(zip(precision, PRECISION_QUERIES))
    )
    if len(results) != 11:
        raise ValueError('source evidence coverage missing')
    print(json.dumps({'scope': SCOPE, 'results': results}, indent=2))
    return 0 if all(r['status'] == 'PASS' for r in results) else 1


def execute():
    """Replay against a unique own container. Returns 0/1/2. Never SystemExit."""
    container = unique_name()
    if not is_own_container(container):
        print(json.dumps({'status': 'UNKNOWN', 'reason': 'container name is not unique own'}))
        return 2
    maybe_own = False
    code = 2
    try:
        load_evidence()
        maybe_own = True
        run(docker_run_args(container))
        wait_ready(container)
        code = replay(lambda q: sql(container, q))
    except Exception as e:
        print(json.dumps({'status': 'UNKNOWN', 'reason': str(e)[:400]}))
        code = 2
    finally:
        if maybe_own:
            try:
                cleanup_own(container)
            except Exception as e:
                print(json.dumps({'cleanup': 'UNKNOWN', 'container': container, 'reason': str(e)[:200]}))
                code = 2
    return code


if __name__ == '__main__':
    raise SystemExit(execute())
