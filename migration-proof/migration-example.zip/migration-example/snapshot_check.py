"""Shape-only snapshot validator. Does not run SQL or inspect engine provenance."""

from decimal import Decimal, InvalidOperation

_PASS = {"status": "PASS"}
_UNKNOWN = {"status": "UNKNOWN", "reason": "invalid snapshot shape"}

_TABLE_COUNT = 10  # engine metadata first, then nine numeric result tables
_NUMERIC_TABLE_COUNT = 9
_CASE_COUNT = 9
_PRECISION_COUNT = 2
_CASE_WIDTH = 3


def validate(tables, cases, precision):
    """Return PASS or UNKNOWN with a generic reason. Snapshot shape only."""
    try:
        if not _is_list(tables) or not _is_list(cases) or not _is_list(precision):
            return dict(_UNKNOWN)
        if (
            len(tables) != _TABLE_COUNT
            or len(cases) != _CASE_COUNT
            or len(precision) != _PRECISION_COUNT
        ):
            return dict(_UNKNOWN)
        if len(tables) != 1 + _NUMERIC_TABLE_COUNT:
            return dict(_UNKNOWN)
        if not _table_ok(tables[0], numeric=False):
            return dict(_UNKNOWN)
        for table in tables[1:]:
            if not _table_ok(table, numeric=True):
                return dict(_UNKNOWN)
        for table in precision:
            if not _table_ok(table, numeric=True):
                return dict(_UNKNOWN)
        if not _cases_ok(cases):
            return dict(_UNKNOWN)
        return dict(_PASS)
    except Exception:
        return dict(_UNKNOWN)


def _is_list(value):
    return type(value) is list


def _table_ok(table, numeric):
    if not _is_list(table) or not table:
        return False
    headers = table[0]
    if not _headers_ok(headers):
        return False
    width = len(headers)
    for row in table[1:]:
        if not _row_ok(row, width, numeric):
            return False
    return True


def _headers_ok(headers):
    if not _is_list(headers) or not headers:
        return False
    if any(type(header) is not str or header == "" for header in headers):
        return False
    return len(set(headers)) == len(headers)


def _row_ok(row, width, numeric):
    if not _is_list(row) or len(row) != width:
        return False
    if numeric:
        return all(_finite_decimal_string(cell) for cell in row)
    return all(type(cell) is str and cell != "" for cell in row)


def _finite_decimal_string(value):
    if type(value) is bool or type(value) is float:
        return False
    if type(value) is not str:
        return False
    try:
        number = Decimal(value)
    except (InvalidOperation, ValueError, TypeError):
        return False
    return number.is_finite()


def _cases_ok(cases):
    labels = []
    for case in cases:
        if not _is_list(case) or len(case) != _CASE_WIDTH:
            return False
        label, source_query, target_query = case
        if not _nonempty_string(label):
            return False
        if not _nonempty_string(source_query) or not _nonempty_string(target_query):
            return False
        labels.append(label)
    return len(set(labels)) == len(labels)


def _nonempty_string(value):
    return type(value) is str and value != ""
